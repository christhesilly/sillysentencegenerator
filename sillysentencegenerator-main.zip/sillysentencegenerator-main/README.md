# sillysentencegenerator
A small silly sentence generator! ^^

This is just a small sentence generator I made!


#If you want to change anything in there, import this into Visual Studio!
